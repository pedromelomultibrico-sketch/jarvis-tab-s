#!/system/bin/sh
# Jarvis Carro - corre no arranque (Magisk service.d)
LOG=/data/local/tmp/jarvis-carro.log
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
echo "$(date) arranque" >> $LOG

# 1) Limitar o processador (menos picos de consumo para a bateria velha)
for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
  d=${f%/scaling_max_freq}; best=""
  for fr in $(cat $d/scaling_available_frequencies 2>/dev/null); do
    if [ "$fr" -le 1300000 ] && { [ -z "$best" ] || [ "$fr" -gt "$best" ]; }; then best=$fr; fi
  done
  [ -n "$best" ] && echo "$best" > "$f" && echo "$(date) $f=$best" >> $LOG
done

# 2) Proteger a bateria: modo loja da Samsung (mantem a carga entre ~60 e 70%)
B=/sys/class/power_supply/battery
for SM in $B/store_mode $B/batt_slate_mode_unused; do
  [ -e "$SM" ] && echo 1 > "$SM" 2>/dev/null && echo "$(date) $SM=1" >> $LOG
done

# 4) Ecra do carro: sem bloqueio, sempre aceso com corrente, animacoes a 0.5x
locksettings set-disabled true >> $LOG 2>&1
settings put global stay_on_while_plugged_in 7
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# 5) Ordens a distancia do Claude (acordar / apagar / reiniciar), pelo Worker "carro"
BB=/data/adb/magisk/busybox
U="https://carro.pedromelomultibrico.workers.dev/?k=q8Zt3vNw7Lp2Xc"
buscar() { $BB wget -q -T 10 -O - "$U" 2>/dev/null || curl -s -m 10 "$U" 2>/dev/null; }
ordens() {
  ultimo=$(date +%s); falhou=0
  while true; do
    r=$(buscar)
    if [ -z "$r" ]; then
      [ $falhou -eq 0 ] && echo "$(date) ordens: sem resposta do servidor" >> $LOG; falhou=1
    else
      falhou=0
      n=${r%%:*}; a=${r#*:}
      case "$n" in ''|*[!0-9]*) n=0;; esac
      if [ "$n" -gt "$ultimo" ]; then
        ultimo=$n
        echo "$(date) ordem: $a" >> $LOG
        case "$a" in
          acordar) input keyevent 224; sleep 1; wm dismiss-keyguard;;
          apagar) input keyevent 223;;
          reiniciar) sync; reboot;;
        esac
      fi
    fi
    sleep 5
  done
}
ordens &

ligado() {
  for p in /sys/class/power_supply/*/online; do
    case "$p" in *battery*) continue;; esac
    [ "$(cat $p 2>/dev/null)" = "1" ] && return 0
  done
  return 1
}

# 3) Sem corrente durante 30 min (carro desligado) ou bateria <=15% sem corrente -> desliga
sem=0
while true; do
  cap=$(cat $B/capacity 2>/dev/null)
  if ligado; then sem=0; else sem=$((sem+1)); fi
  if [ $sem -ge 30 ] || { [ $sem -gt 0 ] && [ "${cap:-100}" -le 15 ]; }; then
    echo "$(date) a desligar (sem corrente ${sem} min, ${cap}%)" >> $LOG
    sync; reboot -p
  fi
  sleep 60
done
